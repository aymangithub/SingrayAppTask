import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { map } from 'rxjs/operators';
import { Item } from '../models/item.model';

@Injectable()
export class ItemsService {
  constructor (
    private apiService: ApiService
  ) {}

  query(): Observable<Item[]> {
  
    return this.apiService
    .get(
      'Items' ,
      new HttpParams()
    );
  }

 

  delete(id) {
    return this.apiService.delete('Items/' + id);
  }

  save(item): Observable<Item> {
    return this.apiService.post(`Items/Create?Name=${item.name}&IsActive=${item.isActive}`, {})
    .pipe(map(data => data.article));
  }



}