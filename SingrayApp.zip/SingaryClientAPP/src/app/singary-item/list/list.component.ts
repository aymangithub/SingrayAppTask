import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Item } from 'src/app/core/models/item.model';
import { ItemsService } from 'src/app/core/services/item.services';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {


  constructor(private itemsService: ItemsService) {

  }


  items: Item[] = [];
  loading = false;


  ngOnInit(): void {
    this.runQuery();
  }
  runQuery() {
    this.loading = true;
    this.items = [];
    this.itemsService.query()
      .subscribe(data => {
        this.loading = false;
        this.items = data['data'];
        console.log(this.items);

      });
  }
  Delete(item) {
    if (confirm("Are you sure?") == false)
      return;
    this.itemsService.delete(item.id);
    this.runQuery();
  }

}
