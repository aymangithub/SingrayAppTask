import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './list/list.component';
import { ItemsService } from '../core/services/item.services';
import { ApiService } from '../core/services/api.service';
import { AddComponent } from './add/add.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [ListComponent, AddComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  providers: [ApiService,ItemsService],
  exports:[
    ListComponent,
    AddComponent
  ]
})
export class SingaryItemModule { }
