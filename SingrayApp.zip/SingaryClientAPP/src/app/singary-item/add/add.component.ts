import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { Item } from 'src/app/core/models/item.model';
import { ItemsService } from 'src/app/core/services/item.services';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  item: Item = {} as Item;
  errors: [] = [];
  isSubmitting = false;
  ischecked: boolean;

  constructor(private itemsService: ItemsService,
    private router: Router) {
  }

  ngOnInit(): void {
  }
  AddItem() {
    this.item.isActive = this.ischecked;
    this.isSubmitting = true;


    this.itemsService.save(this.item).subscribe(
      item => {
        this.isSubmitting = false;
        return this.router.navigateByUrl('/');
      },

      err => {
        this.errors = err;
        this.isSubmitting = false;
      }
    );
  }
}
