export const environment = {
  production: true,
  api_url: 'https://localhost:44375/api/

};
